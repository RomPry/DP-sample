/*
Template Name: Nazox - Responsive Bootstrap 4 Admin Dashboard
Author: Themesdesign
Contact: themesdesign.in@gmail.com
File: Jquery knob init Js File
*/

$(function() {
    $(".knob").knob();
});